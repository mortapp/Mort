import { NextResponse, type NextRequest } from 'next/server'
import { createClient } from '@/lib/supabase/server'
export async function POST(req: NextRequest) { const supabase = await createClient(); await supabase.auth.signOut(); return NextResponse.redirect(new URL('/login?message=Signed out', req.url)) }
